void init();
void find_path(char *, char *);
void print_neighbors(char *);
