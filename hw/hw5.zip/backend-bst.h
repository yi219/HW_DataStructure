void add(char [3], char [4]);
void search(char [3]);
void delete(char [3]);
void print_list();
void init_pool();
void print_height();

