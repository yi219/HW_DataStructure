#include <stdio.h>
#include <stdlib.h>   // Necessary for exit()
#include "backend-hash-open-addressing.h"     

#define WELCOME_MESSAGE "Welcome to Address Book!\n"
#define COMMAND_PROMPT "ADDR>"
#define ADD_PROMPT "ADD NAME>>"
#define SEARCH_PROMPT "SEARCH NAME>>"
#define NUMBER_PROMPT "ENTER NUMBER>>>"
#define DELETE_PROMPT "DELETE NAME>>"

#define MAX_STRING_LENGTH 100

int prompt_command(char *, char *);
int prompt_name(char *, char *);
int prompt_number(char *, char *);

int main()
{

  char command[1];
  char name[MAX_STRING_LENGTH], number[MAX_STRING_LENGTH];

  init();

  printf(WELCOME_MESSAGE);

  while (1) {
  restart:
    if (prompt_command(COMMAND_PROMPT, command) != 0 )
      goto restart;
    switch (command[0]) {
    case 'A':
    case 'a':
      if (prompt_name(ADD_PROMPT, name) !=0)
	goto restart;
      if (prompt_number(NUMBER_PROMPT, number) !=0)
	goto restart;
      add(name, number);
      break;
    case 'S':
    case 's':
      if (prompt_name(SEARCH_PROMPT, name) !=0)
	goto restart;
      search(name);
      break;
      /*  We don't have deletion :) 
    case 'D':
    case 'd':
      if (prompt_name(DELETE_PROMPT, name) !=0)
	goto restart;
	delete(name); 
      break;
       */
    case 'Q':
    case 'q':
      printf("Quitting ... \n");
      return 0;
      /*
    case 'P':
    case 'p':
      print_dist();
      break;
      */
    default:
      printf("Please enter a valid command.\n");
      goto restart;
    }
  }
}


int prompt_command(char *s, char *p)
{

  char *q;
  char c;

  while (1) {
    printf("%s ", s);
    fflush(stdout);
    q=p;
    while (1) {
      c=getchar();
      if (c==EOF)
	exit(-1);      // Should let exit() take care of the sudden EOF.
      if (c=='\n')     
	break;
      if (q<p+1)
	*q=c;
      q++;
    }
    if (q==p+1)
      return 0;   // got a good command //
    if (q==p)
      return 1;   // just a <return>  //
    printf("Please type a command.\n");
  }
}


int prompt_name(char *s, char *p)
{

  char *q;
  char c;

  while (1) {
    printf("%s ", s);
    fflush(stdout);
    q=p;
    while (1) {
      c=getchar();
      if (c==EOF)
	exit(-1);      // Should let exit() take care of the sudden EOF.
      if (c=='\n')
	break;
      if (q<p+MAX_STRING_LENGTH)
	*q=c;
      q++;
    }
    if (q==p)
      return 1;   // just a <return>  //
    if (q<=p+MAX_STRING_LENGTH) {
      *q='\0';     // put the end-of-str //
      return 0;   // got a good name //
    }
    printf("A name cannot be longer than %d.\n", MAX_STRING_LENGTH);
  }
}


int prompt_number(char *s, char *p)
{
  char *q;
  char c;

  while (1) {
    printf("%s ", s);
    fflush(stdout);
    q=p;
    while (1) {
      c=getchar();
      if (c==EOF)
	exit(-1);            // Should let exit() take care of the sudden EOF.
      if (c=='\n')
	break;
      if (q<p+MAX_STRING_LENGTH)
	*q=c;
      q++;
    }
    if (q==p)
      return 1;   // just a <return>  //
    if (q<=p+MAX_STRING_LENGTH) {
      *q='\0';     // put the end-of-str //
      return 0;   // got a good number //
    }
    printf("A number cannot be longer than %d.\n", MAX_STRING_LENGTH);
  }
  return 0;
}


