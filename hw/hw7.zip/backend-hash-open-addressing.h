void add(char *, char *);
void search(char *);
void init();

//void debug();
