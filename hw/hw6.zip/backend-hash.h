void add(char [3], char [4]);
void search(char [3]);
void delete(char [3]);
void init();
void print_dist();
